install.packages("rtools")
install.packages("xlsx")

library(survminer)
library("survival")
library("xlsx")
library(MASS)
library(data.table)


#read dataset, only first column and first row characters, other numerical
#Cutoffs, log rank p, HR can differ if you use z-score or RSEM expression values (TCGA: )
#change gene names to remove special characters: "-", ".", "@", ","
setwd("D:/MR/stage2 LMU combis")
cohort <- read.delim("cohort_all_combis.txt", check.names=FALSE, stringsAsFactors=FALSE)

#read gene list
gene <- read.delim("combis.txt", check.names=FALSE, stringsAsFactors=FALSE)
#define genes in column "name" as a list
genes <- gene$Name

#Determine the optimal cutpoint for each variable using 'maxstat' (minprop; the minimal proportion of observations per group)
cutoff <- surv_cutpoint(cohort, time = "RFS", event = "RFS01", variables = genes, minprop = 0.05, progressbar = TRUE)

#Divide each variable values based on the cutpoint returned by surv_cutpoint()
surv_cat <- surv_categorize(cutoff)

#read formulas for surv_fit; use only gene names without "-", ".", "@", "," characters
formula_new <- read.delim("formula_combis.txt", check.names=FALSE, colClasses = "character", header=FALSE)
formulalist <- c(t(formula_new))
#if error, run 1st: pvalue <- surv_pvalue(fit) then re-run:
for (n in 1:2800) {
  #Formula definition and Fit survival curves and visualize
  formulaselection <- formulalist[c(((n-1)*10+1):((n-1)*10+10))]
  formulafinal <- lapply(formulaselection, as.formula)
  fit <- surv_fit(formulafinal, data = surv_cat)
  #Compute P-value Comparing Survival Curves
  pvalue[[n]] <- surv_pvalue(fit)
}


#hazard ratio for multiple genes/variable
#genes_for_HR <- read.delim("C:/Users/AG Hermeking/Documents/MR/R/GSE39852/TCGA_genes.txt", check.names=FALSE, stringsAsFactors=FALSE)
#genes_HR <- genes_for_HR$Name
univ_formulas <- sapply(genes, function(x) as.formula(paste('Surv(RFS, RFS01)~', x)))
univ_models <- lapply(univ_formulas, function(x){coxph(x, data = surv_cat)})
# Extract data 
univ_results <- lapply(univ_models,
                       function(x){ 
                         x <- summary(x)
                         p.value<-signif(x$wald["pvalue"], digits=4)
                         wald.test<-signif(x$wald["test"], digits=4)
                         beta<-signif(x$coef[1], digits=4);#coeficient beta
                         HR <-signif(x$coef[2], digits=4);#exp(beta)
                         HR.confint.lower <- signif(x$conf.int[,"lower .95"], 4)
                         HR.confint.upper <- signif(x$conf.int[,"upper .95"],4)
                         'HR <- paste0(HR, " (", 
                                      HR.confint.lower, "-", HR.confint.upper, ")")'
                         res<-c(beta, HR, HR.confint.lower, HR.confint.upper, wald.test, p.value)
                         names(res)<-c("beta", "HR","95% CI lower", "95% CI upper", "wald.test", 
                                       "p.value")
                         return(res)
                         #return(exp(cbind(coef(x),confint(x))))
                       })
res <- t(as.data.frame(univ_results, check.names = FALSE))

write.table(res, "d:/HR.txt")
write.table(cutoff$cutpoint, "d:/cutoff.txt")
write.matrix(pvalue, "d:/pvalue.txt")
write.table(surv_cat, "d:/survcat.txt")

#single genes p-value
formulafinal <- list (
  Surv(RFS, RFS01) ~  ZXDA,
  Surv(RFS, RFS01) ~  ZXDB,
  Surv(RFS, RFS01) ~  ZXDC,
  Surv(RFS, RFS01) ~  ZYX,
  Surv(RFS, RFS01) ~  ZZEF1,
  Surv(RFS, RFS01) ~  ZZZ3
)
fit <- surv_fit(formulafinal, data = surv_cat)
pvalue <- surv_pvalue(fit)
write.matrix(pvalue, "d:/missing.txt")

